﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
public class MenuCtrl : MonoBehaviour
{

    public void LoadScence(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }
}